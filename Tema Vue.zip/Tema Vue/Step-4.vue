<script>
export default {
  data() {
    return {
      text: ''
    }
  }
}
</script>

<template>
  <input v-model="text" placeholder="Your text goes here">
  <p>{{ text }}</p>
</template>