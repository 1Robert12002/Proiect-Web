<script>
import ChildComp from './ChildComp.vue'

export default {
  components: {
    ChildComp
  }
}
</script>

<template>
  <ChildComp />
</template>


//Child
<template>
  <h2>A Child Component!</h2>
</template>